<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateConcertsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('concerts', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->integer('songcount');
            $table->integer('tickets');
            $table->decimal('baseprice','5','2');
            $table->string('status')->default('pending');
            $table->unsignedBigInteger('artist_id');
            $table->unsignedBigInteger('organizer_id');
            $table->unsignedBigInteger('venue_id')->default('1');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('concerts');
    }
}
